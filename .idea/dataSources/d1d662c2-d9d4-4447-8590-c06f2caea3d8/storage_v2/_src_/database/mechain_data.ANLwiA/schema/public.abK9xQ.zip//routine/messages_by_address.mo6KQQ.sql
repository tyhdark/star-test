create function messages_by_address(addresses text[], types text[], "limit" bigint DEFAULT 100, "offset" bigint DEFAULT 0) returns SETOF message
    stable
    language sql
as
$$
SELECT * FROM message
WHERE (cardinality(types) = 0 OR type = ANY (types))
  AND addresses && involved_accounts_addresses
ORDER BY height DESC LIMIT "limit" OFFSET "offset"
$$;

alter function messages_by_address(text[], text[], bigint, bigint) owner to neil;

